package com.example.myapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.isVisible
import java.io.File
import android.view.ViewGroup.MarginLayoutParams
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.nio.file.Files
import java.nio.file.Paths
import java.nio.file.Path
import java.nio.file.StandardCopyOption



lateinit var linear : LinearLayout
lateinit var nullfile: TextView
lateinit var addfile: FloatingActionButton
lateinit var add:FloatingActionButton
lateinit var adddir:FloatingActionButton
lateinit var copyfileordir:FloatingActionButton
lateinit var nameofcopy:String
lateinit var cross:FloatingActionButton
var m_Text = ""
var copy="none"
class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        add=findViewById(R.id.add)
        addfile=findViewById(R.id.idFABHome)
        linear=findViewById(R.id.body)
        nullfile=findViewById(R.id.textView2)
        adddir=findViewById(R.id.adddir)
        cross=findViewById(R.id.cross)
        copyfileordir=findViewById(R.id.copya)
        copyfileordir.hide()
        copy=intent.getStringExtra("copy").toString()
        Log.i("length",copy)
        if((copy!="none"))
        {
//            Log.i("length", copy)
            copyfileordir.show()
            cross.show()
        }
        fun copyf(source: Path, destination: Path) {
            try {
                if (Files.isDirectory(source)) {
                    // Copy directory
                    Files.walk(source).use { stream ->
                        stream.forEach { sourcePath ->
                            val destinationPath = destination.resolve(source.relativize(sourcePath))
                            Files.copy(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING)
                        }
                    }
                } else {
                    // Copy single file
                    Files.copy(source, destination.resolve(source.fileName), StandardCopyOption.REPLACE_EXISTING)
                }
                println("Copy completed successfully!")
            } catch (e: Exception) {
                println("Error occurred while copying: ${e.message}")
            }
            val textView = TextView(this)
            textView.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            textView.gravity = Gravity.CENTER_VERTICAL
            textView.text = nameofcopy
            textView.height = 150
            textView.layoutParams.width=ViewGroup.LayoutParams.MATCH_PARENT
            textView.textSize= 20F
            textView.setPadding(50,0,0,0)
            val layoutParams = textView.layoutParams as MarginLayoutParams
            layoutParams.setMargins(16, 16, 16, 16)
            textView.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher_data, 0, 0, 0);
            linear.addView(textView)

        }
        fun textviewcreaterfile(name:String)
        {
            val textView = TextView(this)
            textView.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            textView.gravity = Gravity.CENTER_VERTICAL
            textView.text = name
            textView.height = 150
            textView.layoutParams.width=ViewGroup.LayoutParams.MATCH_PARENT
            textView.textSize= 20F
            textView.setPadding(50,0,0,0)
            val layoutParams = textView.layoutParams as MarginLayoutParams
            layoutParams.setMargins(16, 16, 16, 16)
            textView.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher_data, 0, 0, 0);
            linear.addView(textView)
        }
        fun textviewcreaterdir(name:String)
        {
            val textView = TextView(this)
            textView.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            textView.gravity = Gravity.CENTER_VERTICAL
            textView.text = name
            textView.height = 150
            textView.layoutParams.width=ViewGroup.LayoutParams.MATCH_PARENT
            textView.textSize= 20F
            textView.setPadding(50,0,0,0)
            val layoutParams = textView.layoutParams as MarginLayoutParams
            layoutParams.setMargins(16, 16, 16, 16)
            textView.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher, 0, 0, 0);
            linear.addView(textView)
        }

        val intent = intent
        val path = intent.getStringExtra("path")

        val existingFiles = File(path).listFiles()
        var expand=false
        nullfile.isVisible=false
        add.show()
        add.setOnClickListener{
            if(expand==false)
            {
                addfile.show()
                adddir.show()
                expand=true
            }
            else{
                addfile.hide()
                adddir.hide()
                expand=false
            }
        }
        cross.setOnClickListener{
            cross.hide()
            copyfileordir.hide()

        }
        adddir.setOnClickListener{
            val adddirname = EditText(this)
            adddirname.inputType = InputType.TYPE_CLASS_TEXT
            val builder2=AlertDialog.Builder(this)
                .setView(adddirname)
                .setMessage("New Folder Name")
                .setPositiveButton("Ok",null)
                .setNegativeButton("Cancel",null)
                .show()
            val mPositive2Button = builder2.getButton(AlertDialog.BUTTON_POSITIVE)
            mPositive2Button.setOnClickListener {
                val directoryPath1 = path+"/"+adddirname.text.toString() // Specify the path for the new directory

                val directory1 = File(directoryPath1)

                if (!directory1.exists()) {
                    if (directory1.mkdirs()) { // Create the directory and its parent directories if they don't exist
                        textviewcreaterdir(adddirname.text.toString())
                    } else {
                        println("Failed to create directory.")
                    }
                } else {
                    println("Directory already exists.")
                }
                builder2.cancel()
            }
        }
        addfile.setOnClickListener{
            val addname = EditText(this)

            addname.inputType = InputType.TYPE_CLASS_TEXT
            val builder1=AlertDialog.Builder(this)
                .setView(addname)
                .setMessage("New File Name")
                .setPositiveButton("Ok",null)
                .setNegativeButton("Cancel",null)
                .show()
            val mPositive1Button = builder1.getButton(AlertDialog.BUTTON_POSITIVE)
            mPositive1Button.setOnClickListener {
                val directoryPath = path // Specify the path to the directory where you want to create the file
                val fileName = addname.text.toString() // Specify the name of the file you want to create

                val directory = File(directoryPath)
                val file = File(directory, fileName)

                if (!directory.exists()) {
                    directory.mkdirs() // Create the directory if it doesn't exist
                }

                if (file.createNewFile()) {
                    textviewcreaterfile(fileName)
                } else {
                        println("File Not Created")
                }
                builder1.cancel()
            }

        }
        copyfileordir.setOnClickListener{
            copyfileordir.hide()

            copyf(Paths.get(copy),Paths.get(path))
            Log.i("path",intent.getStringExtra("copy").toString())
            copy="none"
            cross.hide()

        }





        if(existingFiles === null )
        {
            nullfile.isVisible=true

        }
        else{
        for (F in existingFiles) {
            Log.i("hjdg",F.getName())
            val textView = TextView(this)
            textView.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            textView.gravity = Gravity.CENTER_VERTICAL
            textView.text = F.getName()
            textView.height = 150
            textView.layoutParams.width=ViewGroup.LayoutParams.MATCH_PARENT
            textView.textSize= 20F
            textView.setPadding(50,0,0,0)
            val layoutParams = textView.layoutParams as MarginLayoutParams
            layoutParams.setMargins(16, 16, 16, 16)
//            textView.setTextColor(Color.parseColor("#FFFFFF"));



            textView.setOnClickListener {

                val popupMenu= PopupMenu(this,textView)
                popupMenu.menuInflater.inflate(R.menu.popup_menu,popupMenu.menu)
                popupMenu.setOnMenuItemClickListener { menuItem ->
                    // Toast message on menu item clicked

                    if(menuItem.itemId==R.id.open)
                    {
                        if(F.isFile)
                    {
                        val intent = Intent(Intent.ACTION_VIEW)
                        val file = File(F.absolutePath)
                        val fileUri: Uri = Uri.fromFile(file)
                        val apkURI: Uri = FileProvider.getUriForFile(
                            applicationContext,
                            applicationContext
                                .getPackageName() + ".provider", F
                        )
                        intent.setDataAndType(apkURI, "*/*")
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

                        val chooserIntent = Intent.createChooser(intent, "Open file with")

                        if (intent.resolveActivity(packageManager) != null) {
                            startActivity(chooserIntent)
                        } else {
                            // No app available to open the file
                            // Handle the error case or provide an appropriate message to the user
                        }

                    }
                    else {
                        val intent = Intent(applicationContext, MainActivity2::class.java)
                        val path: String = F.absolutePath
                            intent.putExtra("path", path)
                            intent.putExtra("copy",copy)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        applicationContext.startActivity(intent)
                    }}
                    else if(menuItem.itemId==R.id.rename){
                        val input = EditText(this)

                        input.inputType = InputType.TYPE_CLASS_TEXT
                        val builder=AlertDialog.Builder(this)
                            .setView(input)
                            .setMessage("New Name")
                            .setPositiveButton("Ok",null)
                            .setNegativeButton("Cancel",null)
                            .show()
                        val mPositiveButton = builder.getButton(AlertDialog.BUTTON_POSITIVE)
                        mPositiveButton.setOnClickListener{
                            m_Text=input.text.toString()

                            val externalStorageDir = File(F.parent)
                            val oldFile = File(externalStorageDir, F.name)
                            val newFile = File(externalStorageDir, input.text.toString())
                            textView.text=input.text.toString()
                            if (oldFile.exists() && !newFile.exists()) {
                                // Rename the file
                                val success = oldFile.renameTo(newFile)

                                if (success) {
                                    println("File renamed successfully.")
                                } else {
                                    println("Failed to rename the file.")
                                }
                            } else {
                                println("Either the old file doesn't exist or the new file already exists.")
                            }

                            Log.i("file name", m_Text)
                            builder.cancel()
                        }

                        builder.show()




                    }
                    else if(menuItem.itemId==R.id.delete){
                        F.delete()
                        textView.isVisible=false
                    }
                    else if(menuItem.itemId==R.id.copy)
                    {
                        println("tried")

                            nameofcopy=F.name
                            copyfileordir.show()
                            copy = F.absolutePath
                            intent.putExtra("copy",copy)
                        println(copy)
                        cross.show()

                    }
                    true
                }


                      popupMenu.show()


                }

                // Add TextView to LinearLayout

                if(F.isDirectory) {

                    textView.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher, 0, 0, 0);
                }
                else if(F.isFile) {

                    textView.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher_data, 0, 0, 0);
                }
            if(!F.isHidden)
                linear.addView(textView)


        }
        }

    }
}